

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class first
 */
@WebServlet("/first")
public class first extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String name = request.getParameter("t1");
		String pass = request.getParameter("t2");
		String email = request.getParameter("t3");
		
		sample s = new sample();
		s.setName(name);
		s.setPassword(pass);
		s.setEmail(email);
		
		int status=SamDao.add(s);
		if(status>0) {
			pw.println("Successfully Registered");
		}
		else{
			System.out.println("Sorry!!!!");
		}
		pw.println("<a href ='index.html'>ReturnToPrevious</a>");
	
	
		
	}
}

